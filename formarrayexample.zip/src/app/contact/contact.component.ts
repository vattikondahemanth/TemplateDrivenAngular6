import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private route: ActivatedRoute, private router: Router,
  ) { }
  ngOnInit() {
    // const id = this.route.snapshot.paramMap.get('id');
    const id = this.route.params.subscribe((param) => {
      console.log(param);
    });

    console.log(id);
    console.log(this.route.params);
    console.log(this.route.snapshot.paramMap.get('id'))
  }
}
