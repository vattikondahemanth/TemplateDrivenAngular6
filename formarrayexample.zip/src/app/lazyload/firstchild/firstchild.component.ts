import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstchild',
  templateUrl: './firstchild.component.html',
  styleUrls: ['./firstchild.component.css']
})
export class FirstchildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
