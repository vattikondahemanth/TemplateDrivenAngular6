import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazyload',
  templateUrl: './lazyload.component.html',
  styleUrls: ['./lazyload.component.css']
})
export class LazyloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
